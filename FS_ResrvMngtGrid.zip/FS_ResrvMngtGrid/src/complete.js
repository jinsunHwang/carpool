const CompleteGrid = {
    data : [],
    grid : {},
    init : function() {
        console.log('complete init');
        LCC.addMessageHandler(message=>this.messageHandler(message));
        this.initGrid();
        this.initSelector();
        this.initEvent();
    },
    initGrid : function() {
        const grid = new wijmo.grid.FlexGrid("#theGrid",{
            allowSorting: true,
            showSort: true,
            stickyHeaders: true,
            showMarquee: true,
            autoGenerateColumns: false,
            columns : [
                { binding: 'CreatedDate', header: '입력일시', width: 140, align: 'center', isReadOnly: true},
                { binding: 'RequesterCode', header: '예약자코드', width: 90, align: 'center', isReadOnly: true},
                { binding: 'Requester', header: '예약자', width: 90, align: 'center', isReadOnly: true},
                { binding: 'DivCode', header: '사업부', width: 60, align: 'center', isReadOnly: true},
                { binding: 'requestPartNo', header: '요청PARTNO', width: 107, align: 'center',isReadOnly: true},
                { binding: 'receivedPartNo', header: '입고PARTNO', width: 107, align: 'center', isReadOnly: true},
                // { binding: 'ModelName', header: '대표모델', width: 150, align: 'center', isReadOnly: true},
                { binding: 'PartDesc', header: '품명', width: 120, align: 'center', isReadOnly: true},
                { binding: 'ShippedDepartMent', header: '출고부서', width: 120, align: 'center', isReadOnly: true},
                { binding: 'ResrvStatus', header: '예약상태', width: 80, align: 'center', isReadOnly: true},
                { binding: 'requestQuantity', header: '요청', width: 50, align: 'center', isReadOnly: true},
                { binding: 'receivedQuantity', header: '입고', width: 50, align: 'center', isReadOnly: true},
                { binding: 'orgQuantity', header: '정리', width: 50, align: 'center', isReadOnly: true},
                { binding: 'ReceiveFormat', header: '접수번호', width: 150, align: 'center', isReadOnly: true},
                { binding: 'processLabel', header: '처리코드', width: 150, align: 'center', isReadOnly: true},
                { binding: 'CancelReason', header: '취소사유', width: 150, align: 'center'},
                { binding: 'CancelUser', header: '실통화자', width: 150, align: 'center', isReadOnly: true},
                { binding: 'AllocCancelYN', header: 'PO취소', width: 150, align: 'center', isReadOnly: true},
                { binding: 'Remark', header: '공급불가사유', width: 150, align: 'center', isReadOnly: true},
                { binding: 'NotShippedQuantity', header: '수량', width: 50, align: 'center', isReadOnly: true},
                { binding: 'productLocationName', header: '적치장소', width: 120, align: 'center', isReadOnly: true},
                { binding: 'rsvDate', header: '입고일시', width: 120, align: 'center', isReadOnly: true},
                { binding: 'CustPrice', header: '소비자가', width: 120, align: 'center', isReadOnly: true},
                { binding: 'prliRemark', header: '특기사항', width: 120, align: 'center'},
                { binding: 'ResrvNumber', header: '예약번호', width: 120, align: 'center', isReadOnly: true},
                { binding: 'rsrvSeq', header: '항번', width: 50, align: 'center', isReadOnly: true}, /*약속 채번*/
                { binding: 'orderNumber', header: '주문번호', width: 120, align: 'center', isReadOnly: true},
                { binding: 'orderSeq', header: '항번', width: 50, align: 'center', isReadOnly: true}, /*주문 채번*/
                { binding: 'CreatedByName', header: '입력자', width: 70, align: 'center', isReadOnly: true},
                { binding: 'completeName', header: '처리자', width: 150, align: 'center', isReadOnly: true},
                { binding: 'completeDate', header: '완료일시', width: 150, align: 'center', isReadOnly: true},
                { binding: 'OrderChannelName', header: '주문채널', width: 120, align: 'center', isReadOnly: true},
                { binding: 'highDept', header: '부서명', width: 150, align: 'center', isReadOnly: true},
                { binding: 'CreatedBySVCCODE', header: '센터코드', width: 150, align: 'center', isReadOnly: true},
                { binding: 'LocationName', header: '센터명', width: 150, align: 'center', isReadOnly: true},
            ],
            itemsSource : [...this.data],
        });
        this.grid = grid;

    },
    initSelector : function() {
        const selector = new wijmo.grid.selector.Selector(this.grid,{
            itemChecked:(s,e)=>{
                const selectedList =this.grid.selectedRows.map(item=>{
                    const eachItemData = item.dataItem;
                    const isSelectorChecked = item.isSelected;
                    if(isSelectorChecked){
                        return eachItemData;
                    }
                }).filter(item=>item);
                LCC.sendMessage({'type':'selectedGridComplete',selectedList});
            }
        });
        this.grid.headersVisibility = wijmo.grid.HeadersVisibility.All;
        selector.column = this.grid.rowHeaders.columns[0];
    },
    initEvent : function() {
        const tip = new wijmo.Tooltip();
        const self = this;
        const grid = this.grid;
        // Tooltip Show Event
        grid.hostElement.addEventListener('mousemove', function (e) {
            self.showTooltip(tip,self,grid,e);
        });
        // Tooltip Hide Event
        grid.hostElement.addEventListener('mouseout', function (e) {
            tip.hide();
        });
        // Cell Click Event
        grid.hostElement.addEventListener('click', function(e) {
            self.cellClickEvent(grid,e,self);
        });
    },
    showTooltip : function(tip,self,grid,e) {
        const ht = grid.hitTest(e.pageX, e.pageY);
        if (ht.cellType === wijmo.grid.CellType.Cell ) {
            const rng = ht.range;
            const cellElement = document.elementFromPoint(e.clientX, e.clientY),
                cellBounds = grid.getCellBoundingRect(ht.row, ht.col),
                data = wijmo.escapeHtml(grid.getCellData(rng.row, rng.col, true));
            if (cellElement.className.indexOf('wj-cell') > -1) {
                tip.show(grid.hostElement, data, cellBounds);
            } else {
                tip.hide();
            }
        }

    },
    cellClickEvent : function(grid,e,self) {
        const ht = grid.hitTest(e.pageX, e.pageY);
        const col = ht.col;
        const row = ht.row;
        let item = [];
        if (ht.panel === grid.cells) {
            item = ht.panel.rows[row].dataItem;
            LCC.sendMessage({'type':'cellClick', item});
        }
    },
    messageHandler : function(message) {
        const rowItem = [];
        switch (message.name.type) {
            case 'getSearchListComplete':
                this.grid.rows.clear();
                const items = message.name.listPRLI;
                let userPermission = message.name.userPermission;
                let userCode = message.name.userCode;
                let userCenterCode = message.name.userCenterCode;
                let userSMName = message.name.userSMName;
                this.data.splice(0,this.data.length);
                this.data = items.map((item,i)=>{
                    const row = new wijmo.grid.Row();
                    row.dataItem=item;
                    // row.dataItem.processCode = item.processCode ? `${item.pocessLabel.split('_')[0]}[${item.pocessLabel.split('_')[1]}]` : '';
                    row.dataItem.inputUserInfo = `${item.CreatedByName}${item.userEmplCode ? '['+item.userEmplCode+']' : ''}`;
                    // row.dataItem.rsvDate = item.ShippedDepartMent === item.LocationName ? item.CreatedDate.split(' ')[0].replaceAll('.','-') : item.rsvDate;
                    row.dataItem.ReceiveFormat = item.ReceiveNumber ? `${item.ReceiveNumber}${item.contactName ? ' ['+item.contactName+']' : ''}` : '';
                    this.grid.rows.push(row);
                    return item;
                })
                this.grid.itemsSource=this.data;
                break;
            case 'downloadExcel' :
                let gridData=this.grid.rows.map(item=>item.dataItem);
                try {
                    let book = wijmo.grid.xlsx.FlexGridXlsxConverter.saveAsync(this.grid,{
                        includeColumnHeaders: true,
                        includeRowHeaders: false,
                        formatItem:null
                    }, '예약관리_처리완료목록.xlsx');
                }
                catch (ex) {
                    console.error('에러;', ex);
                }
                break;
        }
    },
}