
const Customer = (() => {
    
    const Grid = {

        init: () => {
            console.log("hello customer in other js");

            LCC.addMessageHandler(message => messageHandler(message));

            console.log("hello customer");

            var data = [];
            
            // data.push({
            //     DIVCODE : 'CNZ',
            //     ProductCode : 'MAN62569301',
            //     CHECK : false,
            //     Location : '14B01A',
            //     ProductName : 'Basket,Door',
            //     MODELName : 'R-T872VBRDS.ZESZ',
            //     RESRV_QTY : 0,
            //     fm_Available_Quantity : 21,
            //     itemCount : 1,
            //     Customerdiscount : false,
            //     amount : 6500,
            //     Price : 6500,
            //     ParentLocation : '동대문서비스센터',
            //     wholeInventory : '전국재고',
            //     promiseDate : new Date(2022, 8, 19),
            //     remarks : '',
            //     order : false,
            //     TECH_PART_YN : 'N'
            // });

            // data.push({
            //     DIVCODE : 'CNZ',
            //     ProductCode : 'CBZ82564284',
            //     CHECK : false,
            //     Location : '05B01A',
            //     ProductName : 'Basket,Door',
            //     MODELName : 'R-T504VDRDS.AKOR',
            //     RESRV_QTY : 0,
            //     fm_Available_Quantity : 15,
            //     itemCount : 1,
            //     Customerdiscount : false,
            //     amount : 6000,
            //     Price : 6000,
            //     ParentLocation : '동대문서비스센터',
            //     wholeInventory : '전국재고',
            //     promiseDate : new Date(2022, 9, 10),
            //     remarks : '',
            //     order : false,
            //     TECH_PART_YN : 'N'
            // });

            // data.push({
            //     DIVCODE : 'NFE',
            //     ProductCode : 'ANE65584112',
            //     CHECK : false,
            //     Location : '16D04E',
            //     ProductName : 'Door Assembly,Home Bar',
            //     MODELName : 'S-T512VDBAS.ACJE',
            //     RESRV_QTY : 0,
            //     fm_Available_Quantity : 16,
            //     itemCount : 1,
            //     Customerdiscount : false,
            //     amount : 7000,
            //     Price : 7000,
            //     ParentLocation : '서초서비스센터',
            //     wholeInventory : '전국재고',
            //     promiseDate : new Date(2022, 8, 30),
            //     remarks : '',
            //     order : false,
            //     TECH_PART_YN : 'N'
            // });

            // data.push({
            //     DIVCODE : 'YNA',
            //     ProductCode : 'NHY14785236',
            //     CHECK : false,
            //     Location : '05B01A',
            //     ProductName : 'Filter Assembly,Air Cleaner',
            //     MODELName : 'M-M270TC',
            //     RESRV_QTY : 0,
            //     fm_Available_Quantity : 18,
            //     itemCount : 1,
            //     Customerdiscount : false,
            //     amount : 8000,
            //     Price : 8000,
            //     ParentLocation : '양천서비스센터',
            //     wholeInventory : '전국재고',
            //     promiseDate : new Date(2022, 9, 2),
            //     remarks : '',
            //     order : false,
            //     TECH_PART_YN : 'N'
            // });

            // data.push({
            //     DIVCODE : 'YNA',
            //     ProductCode : 'NHY14785236',
            //     CHECK : false,
            //     Location : '05B01A',
            //     ProductName : 'Filter Assembly,Air Cleaner',
            //     MODELName : 'M-M270TC',
            //     RESRV_QTY : 0,
            //     fm_Available_Quantity : 18,
            //     itemCount : 1,
            //     Customerdiscount : false,
            //     amount : 8000,
            //     Price : 8000,
            //     ParentLocation : '양천서비스센터',
            //     wholeInventory : '전국재고',
            //     promiseDate : new Date(2022, 9, 2),
            //     remarks : '',
            //     order : false,
            //     TECH_PART_YN : 'N'
            // });

            // data.push({
            //     DIVCODE : 'KHE',
            //     ProductCode : 'MBG15483205',
            //     CHECK : false,
            //     Location : '14B01A',
            //     ProductName : 'Basket,Window',
            //     MODELName : 'S833TW30B.CKOR',
            //     RESRV_QTY : 0,
            //     fm_Available_Quantity : 12,
            //     itemCount : 1,
            //     Customerdiscount : false,
            //     amount : 9000,
            //     Price : 9000,
            //     ParentLocation : '강서서비스센터',
            //     wholeInventory : '전국재고',
            //     promiseDate : new Date(2022, 9, 14),
            //     remarks : '',
            //     order : false,
            //     TECH_PART_YN : 'N'
            // });

            // create the Grid
            var grid = new wijmo.grid.FlexGrid("#theGrid",{
                allowSorting: false,
                showSort: false,
                autoGenerateColumns: false,
                stickyHeaders: true,
                columns: [
                    { binding: 'DIVCODE', header: '사업부', width: 52, align: 'center', isReadOnly: true},
                    { 
                        binding: 'ProductCode', header: 'PART_NO', width: 97, align: 'center', isReadOnly: true

                    },
                    { binding: 'CHECKED', header: '원', width: 35, align: 'center', dataType: 'Boolean', isReadOnly: true},
                    { binding: 'Location', header: '적치장소', width: 67, align: 'center', isReadOnly: true},
                    { binding: 'ProductName', header: '품명', width: 226, isReadOnly: true},
                    { binding: 'MODELName', header: '모델', width: 248, isReadOnly: true},
                    { binding: 'RESRV_QTY', header: '약속', width: 45, align: 'right', isReadOnly: true},
                    { binding: 'fm_Available_Quantity', header: '가용', width: 45, align: 'right', isReadOnly: true},
                    { binding: 'itemCount', header: '판매', width: 45, align: 'right', mask: '9999'},
                    { binding: 'checkDiscount', header: '할인', dataType: 'Boolean', width: 45},
                    { binding: 'Price', header: '금액', width: 74, align: 'right', isReadOnly: true},
                    { binding: 'Price', header: '소비자가', width: 74, align: 'right', isReadOnly: true},
                    { binding: 'ParentLocation', header: '출고부서', width: 145, isReadOnly: true},

                    {
                        binding: 'wholeInventory',
                        header: '전국재고',
                        width: 80,
                        cellTemplate: wijmo.grid.cellmaker.CellMaker.makeButton({
                            text: '조회',
                            click: (e, ctx) => {
                                console.log("Wijmo 전국재고 item :: " + JSON.stringify(ctx.item));
                                var item = ctx.item;
                                LCC.sendMessage({'type':'showWholeInventory', item});
                            }
                        })
                    },
                    { binding: 'promiseDate', header: '약속일자', width: 83, align: 'center', isReadOnly: true},
                    { binding: 'remarks', header: '특기사항', width: 310},
                    { binding: 'checkOrder', header: '주문', dataType: 'Boolean', width: 45}
                ],
                itemsSource : data,
                
                // s : FlexGrid, e : CellEditEndingEventArgs
                cellEditEnding: (s, e) => {

                    // 데이터 편집하려는 cell의 위치 및 cell이 포함된 그리드 행
                    var selectedItems = s.selectedItems[0];
                    console.log("selected rowItem :: " + JSON.stringify(selectedItems));
                    var selectedRow = e.row;
                    var selectedCol = e.col;

                    // 데이터 편집하려는 cell의 Header Label명
                    var selectedHeader = e.getColumn().header;
                    console.log("get Selected Column Header :: " + selectedHeader);

                    // 데이터 편집하려는 cell의 key값
                    var selectedKeys = Object.keys(selectedItems)[selectedCol];
                    console.log("get Selected Keys :: " + selectedKeys);

                    console.log("get Selected Detail Items :: " + selectedItems[selectedKeys]);

                    // 그리드 내 변경된 값
                    var editValue = s.activeEditor.value;

                    if(selectedHeader == '판매'){
                        // 판매수량 입력할 시 Validation
                        // 0 입력시 1로 변환
                        // 총 판매수량이 가용수량을 넘길 시 1로 변환

                        editValue = editValue.replace(/\_/g,'');
                        editValue *= 1;

                        if(editValue == 0){
                            s.activeEditor.value = 1;
                            selectedItems.itemCount = 1;
                        }
                        else{
                            console.log('Edit Event Value :: ' + editValue);
            
                            selectedItems.itemCount = editValue;
                        }

                        // console.log('Edit Event Value :: ' + editValue);
            
                        // selectedItems.itemCount = editValue;
            
                        var SalesQuantity = 0;
            
                        s.rows.forEach(item => {
                            if(selectedItems.ProductCode == item.dataItem.ProductCode &&
                               selectedItems.Location == item.dataItem.Location &&
                               selectedItems.ParentLocation == item.dataItem.ParentLocation){
                                SalesQuantity += item.dataItem.itemCount * 1;
                            }
                        });
            
                        console.log("SalesQuantity :: " + SalesQuantity);
            
                        if(SalesQuantity > selectedItems.fm_Available_Quantity){
                            s.activeEditor.value = 1;
                            selectedItems.itemCount = 1;
            
                            LCC.sendMessage({'type':'overSales'});
                        }


                        selectedItems.ASCPrice = selectedItems.Price * selectedItems.itemCount;
                    }

                    console.log("rows :: " + JSON.stringify(s.rows[s.selectedRanges[0]._row].dataItem));
                },
                cellEditEnded: (s, e) => {

                    // Wijmo -> Salesforce로 보낼 탭 내 그리드 데이터 List
                    var rowItem= [];

                    s.rows.forEach(rows => {
                        rowItem.push(rows.dataItem);
                    });

                    LCC.sendMessage({'type':'getRowItem', rowItem});
                }
            });

            // create the Selector (Checkbox)
            let selector = new wijmo.grid.selector.Selector(grid, {});

            grid.headersVisibility = wijmo.grid.HeadersVisibility.All;
            selector.column = grid.rowHeaders.columns[0];
            
            // create the Tooltip
            var tip = new wijmo.Tooltip(),
            rng = null;

            // Tooltip Show Event
            grid.hostElement.addEventListener('mousemove', function (e) {
                var ht = grid.hitTest(e.pageX, e.pageY);
                if (!ht.range.equals(rng)) {
                    if (ht.cellType == wijmo.grid.CellType.Cell && (ht.col != 2 && ht.col != 9 && ht.col != 13 && ht.col != 16)) {
                        rng = ht.range;
                        var cellElement = document.elementFromPoint(e.clientX, e.clientY),
                            cellBounds = grid.getCellBoundingRect(ht.row, ht.col),
                            data = wijmo.escapeHtml(grid.getCellData(rng.row, rng.col, true));
                        if (cellElement.className.indexOf('wj-cell') > -1) {
                            tip.show(grid.hostElement, data, cellBounds);
                        } else {
                            tip.hide();
                        }
                    }
                }
            });
        
            // Tooltip Hide Event
            grid.hostElement.addEventListener('mouseout', function (e) {
                tip.hide();
                rng = null;
            });

            // Double Click Event
            grid.hostElement.addEventListener('dblclick', function(e) {
                console.log('Double Click');
                var ht = grid.hitTest(e.pageX, e.pageY);

                var col = ht.col;
                var row = ht.row;
                if (ht.panel === grid.cells) {
                var item = ht.panel.rows[row].dataItem;
                //   console.log("Wijmo item :: " + JSON.stringify(item));
                }

                LCC.sendMessage({'type':'dblclick', item});
            });

            // Message Event (from Salesforce) Handler
            const messageHandler = (message) => {

                console.log('messageHandler', message.name);
                var rowItem = [];

                switch (message.name.type){
                    case 'addRow':
                        var row= new wijmo.grid.Row();			

                        row.dataItem = {
                            DIVCODE : '',
                            ProductCode : '',
                            CHECKED : false,
                            Location : '',
                            ProductName : '',
                            MODELName : '',
                            RESRV_QTY : 0,
                            fm_Available_Quantity : 0,
                            itemCount : 1,
                            checkDiscount : false,
                            ASCPrice : 0,
                            Price : 0,
                            ParentLocation : '',
                            wholeInventory : '전국재고',
                            promiseDate : '',
                            remarks : '',
                            checkOrder : false
                        };

                        grid.rows.push(row);

                        // 그리드 추가 후 SF에 송신해서 attribute set

                        grid.rows.forEach(rows => {
                            rowItem.push(rows.dataItem);
                        });

                        console.log("Wijmo Return rowItem :: " + JSON.stringify(rowItem));

                        LCC.sendMessage({'type':'getRowItem', rowItem});

                        console.log("Wij addRow end");
                        break;
                    case 'removeRow' :
                        var selected = grid.selectedRows;
                        var selectedList = [];
                        selected.forEach(item => {
                            selectedList.push(item._idx);
                        })

                        selectedList.reverse();

                        console.log("selectedList :: " + selectedList);

                        for(var i = 0; i < selectedList.length; i++){
                            grid.rows.splice(selectedList[i], 1);
                        }

                        // 그리드 삭제 후 SF에 송신해서 attribute set

                        grid.rows.forEach(rows => {
                            rowItem.push(rows.dataItem);
                        });

                        console.log("Wijmo Return rowItem :: " + JSON.stringify(rowItem));

                        LCC.sendMessage({'type':'getRowItem', rowItem});

                        console.log("Wij removeRow end");
                        break;
                    case 'getRowItem' :
                        grid.rows.forEach(rows => {
                            rowItem.push(rows.dataItem);
                        });

                        console.log("Wijmo Return rowItem :: " + JSON.stringify(rowItem));

                        LCC.sendMessage({'type':'getRowItem', rowItem});

                        break;
                    case 'clearRow' :
                        grid.rows.clear();
                        break;
                    case 'addItem':
                        console.log('messageHandler', JSON.stringify(message.name.item));
                        
                        var items = message.name.item;

                        var row = new wijmo.grid.Row();
                        row.dataItem = items;
                        grid.rows.push(row);
        
                        console.log("Wij addItem end");

                        grid.rows.forEach(rows => {
                            rowItem.push(rows.dataItem);
                        });

                        console.log("Wijmo Return rowItem :: " + JSON.stringify(rowItem));

                        LCC.sendMessage({'type':'getRowItem', rowItem});

                        break;
                    case 'addList':
                        console.log('messageHandler', JSON.stringify(message.name.item));
                        
                        var itemList = message.name.item;

                        itemList.forEach(items => {
                            var row = new wijmo.grid.Row();
                            row.dataItem = items;
                            grid.rows.push(row);
                        });
        
                        console.log("Wij addList end");
                        break;
                }
            };

            console.log("customer load end");
            LCC.sendMessage({'type' : 'spinnerOff'});
        }
    };

    // Apex 호출
	const apex = {

		// Lookup 필드 검색
		search: (query, methodName) => {
			return new Promise((resolve, reject) => {
				Visualforce.remoting.Manager.invokeAction(
					`Wijmo_RequestPartsController.` + methodName,
					query,
					(result, event) => {
						resolve(result);
					},
					{escape: false},
					{buffer: false}
				);
			});
		},
    };

    // Lookup 관련
	const lookup = {

        refineLookupItems: (result, callback) => {
            console.log('result : ', result);
			let items = [];
			items = [...result];
			callback(items);
		},

		// Lookup - ItemsSourceFunction
		lookupItemsSourceFunction: (query, max, callback, methodName) => {
            console.log('query : ' + query);

            apex.search(query, methodName)
                .then(result => {
                    console.log('result : ', result);
                    lookup.refineLookupItems(result, callback);
                });

		},
    };

    return {
        Grid
        // ,lookup,
        // apex
    }

})();